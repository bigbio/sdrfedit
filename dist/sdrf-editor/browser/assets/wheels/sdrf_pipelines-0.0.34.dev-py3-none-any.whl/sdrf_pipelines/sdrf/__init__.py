"""
SDRF Pipelines v2 module using Pydantic for validation.
"""
